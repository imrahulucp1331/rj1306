<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
      <div class="jumbotron">
		  <h1 class="display-4">Welcome Admin .....</h1>
		  <p class="lead">Here U can modify every thing....</p>
		  <hr class="my-4">

</div>
     <div class="card" style="width: 30rem;">
  <img src="bill2.jpg" class="card-img-top" alt="not found">
  <div class="card-body">
    <h5 class="card-title">BILL INFO</h5>
    <p class="card-text">to get more info & update pls click down</p>
    <a href="billinfo.php" class="btn btn-primary">click here</a>
  </div>
</div>
    
 <div class="card" style="width: 30rem;">
  <img src="Waiter.jpg" class="card-img-top" alt="not found">
  <div class="card-body">
    <h5 class="card-title">waiter</h5>
    <p class="card-text">to get more info & update pls click down</p>
    <a href="waiterinfo.php" class="btn btn-primary">click here</a>
  </div>
</div>



   <div class="card" style="width: 30rem;">
  <img src="manager2.jpg" class="card-img-top" alt="not found">
  <div class="card-body">
    <h5 class="card-title">manager</h5>
    <p class="card-text">to get more info & update pls click down</p>
    <a href="managerinfo.php" class="btn btn-primary">click here</a>
  </div>
</div>

   <div class="card" style="width: 30rem;">
  <img src="dish2.jpg" class="card-img-top" alt="not found">
  <div class="card-body">
    <h5 class="card-title">dishes</h5>
    <p class="card-text">to get more info & update pls click down</p>
    <a href="dishinfo.php" class="btn btn-primary">click here</a><br><br>
    <a href="index.php" class="btn btn-primary">logout</a>
  </div>
</div>




</body>
</html>